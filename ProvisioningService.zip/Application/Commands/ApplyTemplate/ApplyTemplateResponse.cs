namespace Application.Commands.ApplyTemplate;

public class ApplyTemplateResponse(string message) : BaseResponse(message)
{
    
}