using MediatR;

namespace Application.Commands.CreateSpoSite;

public class CreateSpoSiteResponse(string message) : BaseResponse(message)
{
    
}