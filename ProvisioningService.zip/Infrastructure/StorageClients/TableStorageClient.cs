using Application.StorageClients;
using Azure;
using Azure.Data.Tables;

namespace Infrastructure.StorageClients;

public class TableStorageClient : ITableStorageClient
{
    private const string ResourcePath = "SolutionsMetadataTable";
    private readonly TableClient _tableClient;
    private readonly InfrastructureSettings _settings;

    public TableStorageClient(TableServiceClient tableServiceClient, InfrastructureSettings settings)
    {
        _settings = settings;
        _tableClient = tableServiceClient.GetTableClient(ResourcePath);
        _tableClient.CreateIfNotExistsAsync();
    }
    
    public async Task<TableEntity> GetSolutionMetadata(string solutionId)
    {
        return (await _tableClient.GetEntityAsync<TableEntity>("solutions", solutionId)).Value;
    }
    
    
}